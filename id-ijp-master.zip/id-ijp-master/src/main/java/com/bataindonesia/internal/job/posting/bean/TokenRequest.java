package com.bataindonesia.internal.job.posting.bean;

public class TokenRequest {

	
	private String token;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	
	

	
}
