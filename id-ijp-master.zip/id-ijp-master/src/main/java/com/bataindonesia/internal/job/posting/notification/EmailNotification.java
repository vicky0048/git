package com.bataindonesia.internal.job.posting.notification;

public class EmailNotification {
	
	private String[] sendTo;
	
	private String subject;
	
	private String bodyContent;
	

	public String[] getSendTo() {
		return sendTo;
	}

	public void setSendTo(String[] sendTo) {
		this.sendTo = sendTo;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBodyContent() {
		return bodyContent;
	}

	public void setBodyContent(String bodyContent) {
		this.bodyContent = bodyContent;
	}
	
	
	
}
